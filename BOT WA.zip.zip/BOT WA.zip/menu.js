exports.menu = (id, BotName, tampilTanggal, tampilWaktu, instagramlu, whatsapplu, kapanbotaktif, grupch1, grupch2) => {
	return `[★ MENU ${BotName} ★]
  
HALLO JINGAN, ${id.split("@s.whatsapp.net")[0]} 👋️

BOT=RAMA
🗓️️ ${tampilTanggal}
🕘 ${tampilWaktu}

ℹ️ 𝕿𝖊𝖓𝖙𝖆𝖓𝖌𝕭𝖔𝖙 ℹ️

⚜️➸ 🔥info
⚜️➸ 🔥donate
⚜️➸ 🔥ownerbot
⚜️➸ 🔥check
________________________
📂 𝕸𝖊𝖉𝖎𝖆 📂

⚕️➸ %stiker
⚕️➸ %ytmp4
⚕️➸ %randomanime
⚕️➸ %ptl cewek
⚕️➸ %ptl cowok
⚕️➸ %ssweb
⚕️➸ %bitly
⚕️➸ %wikiIn
⚕️➸ %wikiEn
⚕️➸ %loli
⚕️➸ %ytmp3
⚕️➸ %igstalk
⚕️➸ %profileig
⚕️➸ %waifu
⚕️➸ %ig
⚕️➸ %ocr
⚕️➸ %covidID
⚕️➸ %covidcountry
________________________
💠️ 𝕷𝖆𝖎𝖓𝖞𝖆 💠

🔱➸ 🔥pesankosong
🔱➸ 🔥toxic
🔱➸ 🔥say
🔱➸ 🔥pantun
🔱➸ 🔥lirik
🔱➸ 🔥alay
🔱➸ 🔥cektanggal 
🔱➸ 🔥jadwalTVnow
________________________
🔮 𝕻𝖗𝖎𝖒𝖇𝖔𝖓 🔮

⚕️➸ 🔥nama
⚕️➸ 🔥pasangan 
⚕️➸ 🔥zodiak 
________________________
💬 𝕲𝖗𝖚𝖕 𝕸𝖊𝖓𝖚 💬

⚕️➸ 🔥intro
⚕️➸ 🔥groupname
________________________
🔞 𝕹𝕾𝕱𝖂 𝕸𝖊𝖓𝖚 🔞

⚕️➸ 🔥codenuklir
⚕️➸ 🔥nekopoi
⚕️➸ ~*🔥randomhentai*~
⚕️➸ 🔥indohot
______________________
⚠️ 𝖘𝖕𝖆𝖒 ⚠️

⚕️➸ 🔥spamcall
⚕️➸ 🔥spamgmail
⚕️➸ 🔥spamsms
______________________

📖 PUISI 📖

⚕️➸ 🔥puisi1
⚕️➸ 🔥puisi2
⚕️➸ 🔥puisi3
______________________

💡 𝕻𝖀𝕴𝕾𝕴 💡️

⚕️➸ 🔥quotes1
⚕️➸ 🔥quotes2
______________________
🌐 𝕯𝕺𝕸𝕬𝕴𝕹 🌐

⚕️️➸ 🔥checkip
⚕️➸ 🔥ping
⚕️➸ 🔥hostsearch
______________________
🌀 𝕾𝕴𝕸𝕴-𝕾𝕴𝕸𝕴 🌀

⚜️➸ 🔥[Pesanmu]
______________________

Kalo Masih Bingung Chat : 
${wa.me/+62895355566000}


SUBS CHANEL : RISKA GAMING YA

         BY RAMA
      ▌│█║▌║▌║║▌║▌║█│▌
      ▌│█║▌║▌║║▌║▌║█│▌
         BY RAMA


   [★ POWERED BY ${RAMA} ★]`
}
